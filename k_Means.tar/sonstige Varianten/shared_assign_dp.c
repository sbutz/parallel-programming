
#include "cuda_runtime.h"
#include <stdio.h>
#include <time.h>
#include <stdlib.h>

// fuer Ergaenzungen: 
#include <string>
#include <fstream>
#include <iostream>
#define TRENNZEICHEN " "
#define READ_FROM_FILE true
#define POINTSFILE "C:/Users/nbaum/Documents/fu_hagen/parallel/Cluster/Punktdaten/s4.dat"

// Grundsaetzliche Vorgaben
#define NUM_POINTS 5000
#define NUM_K 15
#define MAX_LOOPS 100
#define NUM_THREADS 1024
#define MAX_X 700;
#define MAX_Y 500;

#define TYP int
#define LTYP long

typedef struct {
	TYP x;
	TYP y;
	unsigned int myCentroid;
	LTYP distance; // Distanz vom des Datums vom Zentroid
}Point;

typedef struct {
	TYP x;
	TYP y;
	unsigned int total;
	TYP xsum; // die Summe aller X-Werte der ihm zugehoerigen Punkte
	TYP ysum; // die Summe aller y-Werte der ihm zugehoerigen Punkte
	TYP xdist; // die Bewegung des Zentroids nach Neuberechnung in x-Richtung
	TYP ydist; // die Bewegung des Zentroids nach Neuberechnung in y-Richtung
}Centroid;

bool cudaFail(cudaError_t, char*);
cudaError_t reset_device();
int getPoints(Point*, std::string, int);



__device__ LTYP distance_dev(TYP x1, TYP y1, TYP x2, TYP y2) {
	return (x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2);
}

__global__ void kMeansClusterAssignSharedMemory(Point* p, Centroid* c) {
	const int id = blockIdx.x * blockDim.x + threadIdx.x;
	if (id >= NUM_POINTS) return;
	const int tid = threadIdx.x;

	__shared__ TYP spX[NUM_THREADS];
	__shared__ TYP spY[NUM_THREADS];

	spX[tid] = p[id].x;
	spY[tid] = p[id].y;

	__syncthreads();

	//Punkt zum naechsten Zentroid	
	int cluster = -1;
	LTYP pdist = p[id].distance;


	for (int j = 0; j < NUM_K; ++j) {
		LTYP dist = distance_dev(spX[tid], spY[tid], c[j].x, c[j].y);

		if ((dist < pdist) || (-1 == cluster)) {
			pdist = dist;
			cluster = j;
		}
	}
	p[id].myCentroid = cluster;
}


__global__ void kMeansCentroidUpdate(Point* p, Centroid* c, bool delC)
{
	const int id = blockIdx.x * blockDim.x + threadIdx.x;
	if (id >= NUM_POINTS) return;

	//Thread 0 summiert pro Block
	if (threadIdx.x == 0)
	{
		TYP cXSum[NUM_K] = { 0 };
		TYP cYSum[NUM_K] = { 0 };
		int cTotal[NUM_K] = { 0 };

		//im letzten Block darf die Aufsummierung nicht Ã¼ber NUM_POINTS hinausgehen				
		int loops = blockDim.x;
		if (((blockIdx.x + 1) * blockDim.x) > NUM_POINTS)loops = NUM_POINTS % blockDim.x;

		// um dem Blockanfang fuer die Elemente zu bestimmen
		int offset = blockIdx.x * blockDim.x, j_offset;

		// Bilde die Summen fuer die Neuplatzierung der Zentroide
		for (int j = 0; j < loops; ++j)
		{
			j_offset = offset + j;

			int cid = p[j_offset].myCentroid;
			cXSum[cid] += p[j_offset].x;
			cYSum[cid] += p[j_offset].y;
			cTotal[cid]++;
		}

		//atomare Summierung in den globalen Clustervariablen
		for (int z = 0; z < NUM_K; ++z)
		{
			atomicAdd(&c[z].xsum, cXSum[z]);
			atomicAdd(&c[z].ysum, cYSum[z]);
			atomicAdd(&c[z].total, cTotal[z]);
		}
	}

	__syncthreads();

	//Neuberechnung der Clusterzentren (Summen durch Anzahl zugeordneter Datenpunkte)
	//und Berechnung der Veraenderung der Zentroide in die Distanzen
	if (id >= NUM_K)return;

	TYP ocx = c[id].x;
	TYP ocy = c[id].y;

	c[id].x = c[id].xsum / c[id].total;
	c[id].y = c[id].ysum / c[id].total;

	c[id].xdist = ocx - c[id].x;
	c[id].ydist = ocy - c[id].y;

	if (delC) {
		c[id].xsum = 0;
		c[id].ysum = 0;
		c[id].total = 0;
	}
}



int main()
{
	// grundsaetzliche Variablen
	cudaError_t cudaStatus;
	int psize = NUM_POINTS * sizeof(Point);
	int csize = NUM_K * sizeof(Centroid);
	int blocks = (NUM_POINTS + NUM_THREADS - 1) / NUM_THREADS;

	//Speicherallokation
	Point* hp = (Point*)malloc(psize), * dp = 0;          // Datapoints

	// Centroids
	Centroid* c;  cudaStatus = cudaMallocManaged(&c, csize); if (cudaFail(cudaStatus, "Fehler bei cudaMallocMamaged fÃ¼r c"))return -1;

	//Initialisierung der Datenpunkte		
	if (READ_FROM_FILE) {
		int anz = getPoints(hp, POINTSFILE, NUM_POINTS);
		if (-1 == anz) {
			printf("Datei konnte nicht gelesen werden\n");
			return 1;
		}
	}
	else {
		for (unsigned long i = 0; i < NUM_POINTS; ++i) {
			hp[i].x = rand() % MAX_X; 
			hp[i].y = rand() % MAX_Y; 
		}
	}


	//Initialisierung der ersten Zentroide
	for (int i = 0; i < NUM_K; ++i) {
		c[i].x = hp[i].x;
		c[i].y = hp[i].y;
		c[i].xsum = c[i].ysum = c[i].total = 0;
	}

	//Allokation Datenpunkte werden auf Device kopiert    	
	cudaStatus = cudaMalloc(&dp, psize); if (cudaFail(cudaStatus, "cudaMalloc(dp)"))return -1;
	cudaStatus = cudaMemcpy(dp, hp, psize, cudaMemcpyHostToDevice); if (cudaFail(cudaStatus, "memcpy(hp)"))return -1;

	//Loop, um die Zentroide zu finden
	bool changed = true, maxlooped = false;
	unsigned int loops = 0;
	while (changed && !maxlooped)
	{
		// primaere Zuordnung
		kMeansClusterAssignSharedMemory << <blocks, NUM_THREADS >> > (dp, c);
		cudaDeviceSynchronize();

		//Bestimme die Zentroide neu
		kMeansCentroidUpdate << <blocks, NUM_THREADS >> > (dp, c, true);
		cudaDeviceSynchronize();//*/

		changed = false;
		for (int i = 0; i < NUM_K; ++i) {
			//Blieben die Centroide stehen?
			if ((0 != c[i].xdist) && (0 != c[i].ydist))changed = true;
		}

		// Begrenzung auf maximale Anzahl von Durchlaeufen
		loops++;
		if (!changed)printf("\nkeine weitere Bewegung der Zentroide, Beendigung des Algorithmus\n");
		if ((-1 != MAX_LOOPS) && (loops > MAX_LOOPS)) {
			maxlooped = true;
			printf("\nmaximale Anzahl der Schleifendurchlauefe erreicht, Abbruch des Algorithmus\n");
			loops--;
		}
	}

	printf("Anzahl Loops %d\n", loops);

	cudaFree(c);
	cudaFree(dp);

	return reset_device();
}



// ----------------------------------------------------------------------------------------------------------------------------------

// Hilfsroutine fuer Cuda

cudaError_t reset_device() {
	cudaError_t cudaStatus = cudaDeviceReset();
	if (cudaStatus != cudaSuccess)
		fprintf(stderr, "cudaDeviceReset failed!");
	return cudaStatus;
}

bool cudaFail(cudaError_t cudaStatus, char* dev) {
	if (cudaStatus != cudaSuccess) {
		fprintf(stderr, "Fehler bei ");
		fprintf(stderr, dev);
		fprintf(stderr, "\n");
		return true;
	}
	return false;
}

// Hilfsroutinen zum Laden & Speichern

int getPoints(Point* p, std::string filename, int maxLines) {
	std::fstream new_file;

	// open a file to perform read operation using file object.
	new_file.open(filename, std::ios::in);
	if (new_file.fail()) { printf("\Schreibfehler Datei (getPoints)\n"); return -1; }

	// Checking whether the file is open.
	if (new_file.is_open()) {
		std::string sa, sz1, sz2;
		std::size_t komma;
		int zaehler = 0;
		// Read data from the file object and put it into a string.
		while (getline(new_file, sa) && zaehler < maxLines) {

			komma = sa.find(TRENNZEICHEN);
			if ((komma == std::string::npos) || (komma < 1) || (komma == sa.length())) {
				printf("Falsches Zahlenformat");
				return -1;
			}

			sz1 = sa.substr(0, komma);
			sz2 = sa.substr(komma + 1, sa.length());

			p[zaehler].x = stoi(sz1);
			p[zaehler].y = stoi(sz2);

			zaehler++;
		}

		// Close the file object.
		new_file.close();
		return zaehler;
	}
}

