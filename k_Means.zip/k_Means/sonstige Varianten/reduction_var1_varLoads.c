#include "cuda_runtime.h"
#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <fstream>
#include <iostream>
#include <string>

#define READ_FROM_FILE true
#define TRENNZEICHEN " "
#define VARLOADS 2

#define NUM_POINTS 5000 
#define NUM_K 15
#define MAX_LOOPS 100
#define NUM_THREADS 1024
#define MAX_X 700;
#define MAX_Y 500;

#define POINTSFILE "C:/Users/nbaum/Documents/fu_hagen/parallel/Cluster/Punktdaten/s4.dat"

#define TYP int
#define LTYP long

typedef struct {
	TYP x;
	TYP y;
	unsigned int myCentroid;
	LTYP distance;
}Point;

typedef struct {
	TYP x;
	TYP y;
	unsigned int total;
	TYP xsum;
	TYP ysum;
	TYP xdist;
	TYP ydist;
}Centroid;

int getPoints(Point*, std::string, int);
bool cudaFail(cudaError_t, char*);
cudaError_t reset_device();

__device__ LTYP distance_dev(TYP x1, TYP y1, TYP x2, TYP y2) {
	return (x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2);
}

__global__ void kMeansClusterAssign(Point* p, Centroid* c, TYP* cXSum_arr, TYP* cYSum_arr, TYP* cTotal_arr)
{
	const int id = blockIdx.x * blockDim.x + threadIdx.x;
	if (id >= NUM_POINTS) return;

	//Punkt zum naechsten Zentroid	
	int cluster = -1;
	LTYP pdist = p[id].distance;
	int alt_cluster = p[id].myCentroid;

	for (int j = 0; j < NUM_K; ++j)
	{
		LTYP dist = distance_dev(p[id].x, p[id].y, c[j].x, c[j].y);

		if ((dist < pdist) || (-1 == cluster))
		{
			pdist = dist;
			cluster = j;
		}
	}

	p[id].myCentroid = cluster;

	cXSum_arr[id * NUM_K + cluster] = p[id].x;
	cYSum_arr[id * NUM_K + cluster] = p[id].y;
	cTotal_arr[id * NUM_K + cluster] = 1;
}

__global__ void delete_3arr__TYP(TYP* d1, TYP* d2, TYP* d3) {
	const int id = blockIdx.x * blockDim.x + threadIdx.x;
	if (id >= NUM_POINTS * NUM_K)return;
	d1[id] = d2[id] = d3[id] = 0;
}

__global__ void delete_3__TYP(TYP* d1, TYP* d2, TYP* d3) {
	const int id = blockIdx.x * blockDim.x + threadIdx.x;
	if (id >= NUM_K)return;
	d1[id] = d2[id] = d3[id] = 0;
}


__global__ void copyOutToCentroid(Centroid* c, TYP* cxsum, TYP* cysum, TYP* ctotal) {
	const int id = blockIdx.x * blockDim.x + threadIdx.x;
	if (id >= NUM_K)return;

	c[id].total = ctotal[id];
	c[id].xsum = cxsum[id];
	c[id].ysum = cysum[id];
}

__global__ void kMeansCentroidUpdate(Centroid* c)
{
	const int id = blockIdx.x * blockDim.x + threadIdx.x;
	//Neuberechnung der Clusterzentren
	if (id >= NUM_K)return;

	TYP ocx = c[id].x;
	TYP ocy = c[id].y;

	c[id].x = c[id].xsum / c[id].total;
	c[id].y = c[id].ysum / c[id].total;

	c[id].xdist = ocx - c[id].x;
	c[id].ydist = ocy - c[id].y;

}


__global__ void reduction_arr_modulo_sh_v(TYP* in, TYP* out, const int v) {

	unsigned int id = blockIdx.x * blockDim.x * v + threadIdx.x;
	unsigned int tid = threadIdx.x;

	__shared__ TYP sr[NUM_THREADS];
	sr[tid] = 0;

	if (id > NUM_POINTS * NUM_K - 2)return;
	int index = id;
	for (int i = 0; i < v; ++i) {
		if ((index) < (NUM_K * NUM_POINTS))sr[tid] += in[index];
		index += blockDim.x;
	}

	__syncthreads();

	for (unsigned int s = 1; s < NUM_THREADS; s *= 2) {
		for (unsigned int t = 0; t < NUM_K; ++t) {
			if ((tid - t) % (2 * s * NUM_K) == 0) {

				if (tid + s * NUM_K < NUM_THREADS) {
					sr[tid] += sr[tid + s * NUM_K];
				}
			}
			__syncthreads();
		}
	}

	if (tid < NUM_K)atomicAdd(&out[tid], sr[tid]);
}

int main()
{
	// grundsaetzliche Variablen
	cudaError_t cudaStatus;
	int psize = NUM_POINTS * sizeof(Point);
	int csize = NUM_K * sizeof(Centroid);
	int blocks = (NUM_POINTS + NUM_THREADS - 1) / NUM_THREADS;

	//Speicherallokation
	Point* hp = (Point*)malloc(psize), * dp = 0;          // Datapoints
	cudaStatus = cudaMalloc(&dp, psize); if (cudaFail(cudaStatus, "cudaMalloc(dp)"))return -1;

	// Centroids
	Centroid* hc = (Centroid*)malloc(csize), * dc = 0;
	cudaStatus = cudaMalloc(&dc, csize); if (cudaFail(cudaStatus, "Fehler bei cudaMallocMamaged fuer c"))return -1;

	// Variablen fuer die Reduktionsloesung
	int arr_size_typ = NUM_K * NUM_POINTS * sizeof(TYP);
	TYP* dcxsum_arr, * dcysum_arr, * dctotal_arr, * dcxsum, * dcysum, * dctotal;
	cudaStatus = cudaMalloc(&dcxsum_arr, arr_size_typ); if (cudaFail(cudaStatus, "cudaMalloc(dcxsum_arr)"))return -1;
	cudaStatus = cudaMalloc(&dcysum_arr, arr_size_typ); if (cudaFail(cudaStatus, "cudaMalloc(dcysum_arr)"))return -1;
	cudaStatus = cudaMalloc(&dctotal_arr, arr_size_typ); if (cudaFail(cudaStatus, "cudaMalloc(dctotal_arr)"))return -1;
	cudaStatus = cudaMalloc(&dcxsum, arr_size_typ); if (cudaFail(cudaStatus, "cudaMalloc(dcxsum)"))return -1;
	cudaStatus = cudaMalloc(&dcysum, arr_size_typ); if (cudaFail(cudaStatus, "cudaMalloc(dcysum)"))return -1;
	cudaStatus = cudaMalloc(&dctotal, arr_size_typ); if (cudaFail(cudaStatus, "cudaMalloc(dctotal)"))return -1;


	//Initialisierung der Datenpunkte		
	if (READ_FROM_FILE) {
		int anz = getPoints(hp, POINTSFILE, NUM_POINTS);
		if (-1 == anz) {
			printf("Datei konnte nicht gelesen werden\n");
			return 1;
		}
	}
	else {
		for (unsigned long i = 0; i < NUM_POINTS; ++i) {
			hp[i].x = rand() % MAX_X;
			hp[i].y = rand() % MAX_Y;
		}
	}

	//Initialisierung der ersten Zentroide
	for (int i = 0; i < NUM_K; ++i) {
		hc[i].x = hp[i].x;
		hc[i].y = hp[i].y;
		hc[i].xsum = hc[i].ysum = hc[i].total = 0;
	}

	//Allokation Datenpunkte werden auf Device kopiert    

	cudaStatus = cudaMemcpy(dp, hp, psize, cudaMemcpyHostToDevice); if (cudaFail(cudaStatus, "memcpy(hp)"))return -1;
	cudaStatus = cudaMemcpy(dc, hc, csize, cudaMemcpyHostToDevice); if (cudaFail(cudaStatus, "memcpy(hc)"))return -1;

	int threads = (int)(NUM_THREADS / NUM_K);
	threads *= NUM_K;
	int blocks_arr = (NUM_POINTS * NUM_K + threads - 1) / threads;

	//Loop, um die Zentroide zu finden	
	bool changed = true, maxlooped = false;
	unsigned int loops = 0;
	while (changed && !maxlooped)
	{
		delete_3arr__TYP << <blocks * NUM_K, NUM_THREADS >> > (dcxsum_arr, dcysum_arr, dctotal_arr);
		delete_3__TYP << < blocks, NUM_THREADS >> > (dcxsum, dcysum, dctotal);
		cudaDeviceSynchronize();

		kMeansClusterAssign << <blocks, NUM_THREADS >> > (dp, dc, dcxsum_arr, dcysum_arr, dctotal_arr);
		cudaDeviceSynchronize();

		int blocks_arr_v = (blocks_arr + VARLOADS - 1) / VARLOADS;
		reduction_arr_modulo_sh_v << <blocks_arr_v, threads >> > (dcxsum_arr, dcxsum, VARLOADS);
		reduction_arr_modulo_sh_v << <blocks_arr_v, threads >> > (dcysum_arr, dcysum, VARLOADS);
		reduction_arr_modulo_sh_v << <blocks_arr_v, threads >> > (dctotal_arr, dctotal, VARLOADS);
		cudaDeviceSynchronize();

		copyOutToCentroid << < blocks, NUM_THREADS >> > (dc, dcxsum, dcysum, dctotal);
		cudaDeviceSynchronize();

		kMeansCentroidUpdate << <blocks, NUM_THREADS >> > (dc);
		cudaDeviceSynchronize();

		cudaStatus = cudaMemcpy(hc, dc, csize, cudaMemcpyDeviceToHost); if (cudaFail(cudaStatus, "memcpy(hc) to Host"))return -1;

		changed = false;
		for (int i = 0; i < NUM_K; ++i) {
			//Blieben die Centroide stehen?
			if ((0 != hc[i].xdist) && (0 != hc[i].ydist))changed = true;
		}

		// Begrenzung auf maximale Anzahl von DurchlÃƒÆ’Ã‚Â¤ufen
		loops++;
		if (!changed)printf("\nkeine weitere Bewegung der Zentroide, Beendigung des Algorithmus\n");
		if ((-1 != MAX_LOOPS) && (loops > MAX_LOOPS)) {
			maxlooped = true;
			printf("\nmaximale Anzahl der Schleifendurchlauefe erreicht, Abbruch des Algorithmus\n");
			loops--;
		}
	}

	printf("Anzahl Loops %d\n", loops);

	cudaFree(dc);
	cudaFree(dp);
	free(hc);
	free(hp);
	cudaFree(dcxsum_arr);
	cudaFree(dcysum_arr);
	cudaFree(dctotal_arr);
	cudaFree(dcxsum);
	cudaFree(dcysum);
	cudaFree(dctotal);

	return reset_device();
}



// ----------------------------------------------------------------------------------------------------------------------------------

// Hilfsroutine fuer Cuda

cudaError_t reset_device() {
	cudaError_t cudaStatus = cudaDeviceReset();
	if (cudaStatus != cudaSuccess)
		fprintf(stderr, "cudaDeviceReset failed!");
	return cudaStatus;
}

bool cudaFail(cudaError_t cudaStatus, char* dev) {
	if (cudaStatus != cudaSuccess) {
		fprintf(stderr, "Fehler bei ");
		fprintf(stderr, dev);
		fprintf(stderr, "\n");
		return true;
	}
	return false;
}

// Hilfsroutinen zum Laden & Speichern

int getPoints(Point* p, std::string filename, int maxLines) {
	std::fstream new_file;

	// open a file to perform read operation using file object.
	new_file.open(filename, std::ios::in);
	if (new_file.fail()) { printf("\Schreibfehler Datei (getPoints)\n"); return -1; }

	// Checking whether the file is open.
	if (new_file.is_open()) {
		std::string sa, sz1, sz2;
		std::size_t komma;
		int zaehler = 0;
		// Read data from the file object and put it into a string.
		while (getline(new_file, sa) && zaehler < maxLines) {

			komma = sa.find(TRENNZEICHEN);
			if ((komma == std::string::npos) || (komma < 1) || (komma == sa.length())) {
				printf("Falsches Zahlenformat");
				return -1;
			}

			sz1 = sa.substr(0, komma);
			sz2 = sa.substr(komma + 1, sa.length());

			p[zaehler].x = stoi(sz1);
			p[zaehler].y = stoi(sz2);

			zaehler++;
		}

		// Close the file object.
		new_file.close();
		return zaehler;
	}
}

